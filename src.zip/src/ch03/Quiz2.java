package ch03;

public class Quiz2 {
    public static void main(String[] args) {
        //예상 가
        int score = 85;
        String result = (!(score>90))? "가":"나";
        System.out.println(result);


    }
}
