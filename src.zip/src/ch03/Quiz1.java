package ch03;

public class Quiz1 {
    public static void main(String[] args) {
        //예상 31
        int x = 10;
        int y = 20;
        int z = (++x) + (y--);
        System.out.println(z);
    }
}
