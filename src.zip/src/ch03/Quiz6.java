package ch03;

public class Quiz6 {
    public static void main(String[] args) {
        //예상 true, false
        int x = 10;
        int y = 5;
        System.out.println( (x>7) && (y<= 5) );
        System.out.println( (x%3 == 2) || (y%2 != 1) );


    }
}
