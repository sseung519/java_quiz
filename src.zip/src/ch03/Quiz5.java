package ch03;

public class Quiz5 {
    public static void main(String[] args) {
        //예상 123
        int lengthTop = 5;
        int lengthBottom = 10;
        int height = 7;
//        double area = ();
//        System.out.println(area);


    }
}
