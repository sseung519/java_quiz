package ch03;

public class Quiz10 {
    public static void main(String[] args) {
        int num = 333;
        System.out.println(num / 10 * 10 + 1);

    }
}
